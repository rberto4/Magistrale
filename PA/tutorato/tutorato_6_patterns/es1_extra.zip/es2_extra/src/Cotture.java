public enum Cotture {
    ALSANGUE,MEDIA,BENCOTTO,MOLTOCOTTO
}
