public enum Lingue {
    ITALIANO,INGLESE
}
