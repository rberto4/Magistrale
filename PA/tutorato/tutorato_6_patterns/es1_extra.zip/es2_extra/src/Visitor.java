public interface Visitor {
    void visit (Carota carota);
    void visit (Agnello agnello);
}
